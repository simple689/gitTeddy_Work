﻿namespace TeddyNetCore_EngineData {
    public class DataFile_ServerConfig_ServerCenter : DataFile {
        public DataBase_MySql _mySql;
        public DataBase_ListenSocket _listenSocket;
    }
}
