﻿namespace TeddyNetCore_EngineData {
    public class DataFile_ServerConfig_ServerManager : DataFile {
        public DataBase_RequestSocket _requestSocket;
        public DataBase_ListenSocket _listenSocket;
    }
}
