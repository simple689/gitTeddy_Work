﻿namespace TeddyNetCore_EngineData {
    public class DataFile_CommonConfig : DataFile {
        public DataBase_Server _server;
    }
}
