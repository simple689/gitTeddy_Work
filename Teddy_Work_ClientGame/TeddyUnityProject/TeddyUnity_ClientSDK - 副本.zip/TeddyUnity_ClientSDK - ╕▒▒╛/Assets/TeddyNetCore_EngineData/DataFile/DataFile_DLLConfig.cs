﻿using System.Collections.Generic;

namespace TeddyNetCore_EngineData {
    public class DataFile_DLLConfig : DataFile {
        public Dictionary<string, DataBase_DLL> _dllAry = new Dictionary<string, DataBase_DLL>();
    }
}
