﻿namespace TeddyNetCore_EngineData {
    public class DataFile_ServerConfig_ServerGame : DataFile {
    }
}
