﻿namespace TeddyNetCore_EngineData {
    public class DataFile {
        public string _version;
    }
}
