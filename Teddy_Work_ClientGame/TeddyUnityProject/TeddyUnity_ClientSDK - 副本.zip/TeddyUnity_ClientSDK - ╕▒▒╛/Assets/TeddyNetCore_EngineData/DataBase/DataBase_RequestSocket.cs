﻿namespace TeddyNetCore_EngineData {
    public class DataBase_RequestSocket : DataBase {
        public int _bufferSize;
    }
}
