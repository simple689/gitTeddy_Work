﻿namespace TeddyNetCore_EngineData {
    public class DataBase_ListenSocket : DataBase {
        public int _maxConnectionNum;
        public int _bufferSize;
    }
}
