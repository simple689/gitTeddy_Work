﻿namespace TeddyNetCore_EngineData {
    public class DataBase_Server : DataBase {
        public string _hostLan;
        public string _hostWan;
        public string _hostLocal;
        public int _hostPort;
    }
}
