﻿using TeddyNetCore_EngineEnum;

namespace TeddyNetCore_EngineData {
    public class DataBase_SocketCmd : DataBase {
        public SocketCmdType _socketCmdType;
    }
}
