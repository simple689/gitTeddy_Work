﻿namespace TeddyNetCore_EngineData {
    public class DataBase {
    }
}
