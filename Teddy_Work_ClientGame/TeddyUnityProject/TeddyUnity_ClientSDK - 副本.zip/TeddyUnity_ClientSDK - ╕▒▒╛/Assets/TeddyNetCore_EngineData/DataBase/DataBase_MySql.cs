﻿namespace TeddyNetCore_EngineData {
    public class DataBase_MySql : DataBase {
        public string _host;
        public string _port;
        public string _user;
        public string _password;
        public string _dataBase;
        public string _other;
    }
}
