﻿namespace TeddyNetCore_EngineData {
    public class DataBase_DLL : DataBase {
        public string _name;
        public string _dirDebug;
        public string _dir;
    }
}
