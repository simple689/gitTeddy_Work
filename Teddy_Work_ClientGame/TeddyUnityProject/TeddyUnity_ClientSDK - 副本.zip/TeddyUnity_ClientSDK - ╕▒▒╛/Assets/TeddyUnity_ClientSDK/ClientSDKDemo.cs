﻿using TeddyNetCore_Engine;
using UnityEngine;

public class ClientSDKDemo : MonoBehaviour {
    EngineManager engineManager;
    ClientSDK clientSDK;

    // Use this for initialization
    void Start () {
        engineManager = new EngineManager();
        clientSDK = new ClientSDK();
        clientSDK.init(engineManager);
    }

    // Update is called once per frame
    void Update () {
		
	}
}
