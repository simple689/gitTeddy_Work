﻿namespace TeddyNetCore_EngineEnum {
    public enum MainCmdType {
        DLLType,
        ConfigType,
        HostType,
        ConfigFile,
        Other
    }

    public enum ConfigType {
        Debug
    }

    public enum HostType {
        Lan,
        Wan,
        Local
    }
}
