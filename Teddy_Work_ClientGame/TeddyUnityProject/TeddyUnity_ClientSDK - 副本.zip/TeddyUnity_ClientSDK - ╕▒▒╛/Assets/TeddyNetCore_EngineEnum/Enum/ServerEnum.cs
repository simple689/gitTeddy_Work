﻿namespace TeddyNetCore_EngineEnum {
    public enum ServerType {
        ServerBase,
        ServerCenter,
        ServerFinance,
        ServerGame,
        ServerManager,
        ServerPassport
    }
}
