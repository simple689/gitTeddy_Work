﻿namespace TeddyNetCore_EngineEnum {
    public enum PathType {
        DLL,
        Run
    }
}
