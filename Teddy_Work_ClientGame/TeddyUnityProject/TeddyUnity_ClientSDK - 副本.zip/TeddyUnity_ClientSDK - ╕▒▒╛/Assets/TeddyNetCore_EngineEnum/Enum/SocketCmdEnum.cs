﻿namespace TeddyNetCore_EngineEnum {
    public enum SocketCmdType {
        ConnectSuccess,
        ConnectFail,
        ListenPort
    }
}
