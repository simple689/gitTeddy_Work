﻿namespace TeddyNetCore_Engine {
    public static class Util {
    }
}
